# TODO: Buat Fixed Footer Seluruh Halaman

- [x] Tambahkan CSS untuk fixed footer di assets/css/custom.css
- [ ] Test footer pada halaman utama
